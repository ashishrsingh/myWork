Objective

The purpose of this document is to define the framework and CI/CD pipeline required for the ITP Test Automation.

Steps:-

Identify Framework & Tech Stack 

Setup Framework - Creation of Demo Scenario. Verify flowpath begins with Sharepoint then files moved to Azure Blob Storage. Check Mongodb file or log files to make sure files processed. Finally, using Swagger UI to verify Transport Order API.

CI/CD pipeline - Build workflow using Dotnet with C#.  Setup Job, .NET Core and MSBuild.exe



Scope

The scope of automation testing encompasses various aspects of the software development life cycle and includes the following.

Feature/Functional Testing: Automation test cases to verify that the software functions according to the specified requirements. This includes testing features, user interfaces, APIs, integrations, and workflows.

Regression Testing: Automation test cases to ensure that new changes or updates to the software do not adversely affect existing functionality. This helps in maintaining the stability of the application across multiple releases.

Security Testing: Automating security tests to identify vulnerabilities, threats, and risks in the application. This includes penetration testing, vulnerability scanning and security scanning to ensure that sensitive data is protected, and application is resistant to attacks.

CI/CD Approach for Test Automation

Continuous Integration and Continuous Delivery is set of operating principles and collection of practices that enable application development teams to deliver code changes more frequently and reliably. 

We will recommend the common CI/CD pattern as below for all the automation project in Sainsbury’s Logistic landscape.



We will discuss this approach with all the teams to reach consensus on how plug-in different levels of automation in pipelines to make the agile development process fast and efficient.

Technical Stack

Technical Stack

Versions

.NET

6(Latest Version)

Specflow

3.9.74(Latest Version)

ExtentReports

5.0.2(Latest Version)

Selenium.WebDriver

4.18.1(Latest Version)

Selenium.WebDriver.ChromeDriver

121.0.6167.8500(Latest Version)

Azure.Storage.Blobs

12.19.1(Latest Version)

Sharepoint

21.0(Latest Version)

Xunit

2.4.2(Latest Version)

MongoDb Compass

1.28.4(Latest Version)

Swageer UI

Latest Version

Azure DevOps

Latest Version

Note: As per different teams requirement we will add the more tools