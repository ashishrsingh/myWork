using AutoMapper;
//using Microsoft.AspNetCore.Builder;
//using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Reflection;
//using DEMO.Application;
//using DEMO.Domain.Profiles;
//using TransportInfrastructure.Logger;
//using TransportInfrastructure.Logger.Enums;
//using TransportOperationReportGenerator.Domain;
//using TransportInfrastructure.Data;
//using TransportOperationReportGenerator.Domain.Repositories;
using System;
using ITPAutomation.Infrastucture.Models;

namespace ITPAutomation

{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddSingleton(new LogDetail(LoggerExtension.ToCorrelationId(nameof(TransportOperationReportGenerator)), LogApplicationId.ADT, nameof(TransportOperationReportGenerator)));
            //services.AddSingleton(typeof(ICustomLogger<>), typeof(CustomLogger<>));
            //services.AddSingleton(typeof(IRepository<>), typeof(Repository<>));
            //services.AddSingleton<IDepotRepository, DepotRepository>();
            //services.AddScoped<IOperationalReportProcessor, OperationalReportProcessor>();
            //services.Configure<MongoDBSettings>(Configuration.GetSection(nameof(MongoDBSettings)));
            //services.Configure<MongoDBSettings>(
            //   m =>
            //   {
            //       m.ConnectionString = Configuration["MongoDBConnection"];
            //       m.DataBaseName = Configuration["MongoDBSettings:DataBaseName"];
            //       m.PoolSize = Convert.ToInt32(Configuration["MongoDBSettings:PoolSize"]);
            //       m.DownTime = Convert.ToInt32(Configuration["MongoDBSettings:DownTime"]);
            //   });
            services.Configure<AppSettings>(
                    m =>
                    {
                        m.SharePointSiteUrl = Configuration["SharePointSiteUrl"];
                        m.SharePointUsername = Configuration["SharePointUsername"];
                        m.SharePointStaticPwd = Configuration["SharePointStaticPwd"];
                        m.SharePointClientId = Configuration["SharePointClientId"];
                        m.SharePointTokenEndpoint = Configuration["SharePointTokenEndpoint"];
                        m.SharePointEnvFolder = Configuration["SharePointEnvFolder"];
                        m.SharePointLibrary = Configuration["SharePointLibrary"];
                        m.MaxRetryAttempts = Convert.ToInt32(Configuration["AppSettings:MaxRetryAttempts"]);
                        //m.MongoDBDatabase = Configuration["MongoDBDatabase"];
                    });
            //services.AddControllers();
            services.AddOptions();
            

            //services.AddAutoMapper(Assembly.GetAssembly(typeof(EmaroldProfile)));
            //services.ConfigAllServices(Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
    //    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    //    {
    //        if (env.IsDevelopment())
    //        {
    //            app.UseDeveloperExceptionPage();
    //        }

    //        app.UseHttpsRedirection();

    //        app.UseRouting();

    //        app.UseAuthorization();

    //        app.UseEndpoints(endpoints =>
    //        {
    //            endpoints.MapControllers();
    //        });
    //    }
    }
}
