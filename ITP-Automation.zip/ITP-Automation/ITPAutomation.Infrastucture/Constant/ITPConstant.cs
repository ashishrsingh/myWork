﻿using System;
using System.Diagnostics;

namespace ITPAutomation.Infrastucture
{
    public class ITPConstant
    {
        public static string BasePath = GetTestFilePath("Testdoc", "");
        public static string AppsettingBasePath = GetTestFilePath("", "");
        public static string BlobStoragePlanITPath = "";
        public const string PlanITcontainerName = "planit";
        public const string ExcelcontainerName = "exceloutputs";
        public static readonly string PlanITXMLSamples = Path.Combine(BasePath, @"PlanITXMLSamples/");
        public static readonly string ExcelOutputs = Path.Combine(BasePath, @"ExcelOutputs");
       // public static readonly string XMLFilePath = Path.Combine(BasePath, @"PlanITXMLSamples/Valid/");

        public static string GetTestFilePath(string folderName, string fileName)
        {
            try
            {
                string startupPath = AppDomain.CurrentDomain.BaseDirectory;
                var pathItems = startupPath.Split(Path.DirectorySeparatorChar);
                var pos = pathItems.Reverse().ToList().FindIndex(x => string.Equals("bin", x));
                string projectPath = String.Join(Path.DirectorySeparatorChar.ToString(), pathItems.Take(pathItems.Length - pos - 1));
                string filepath = Path.Combine(projectPath, folderName, fileName);
                return filepath;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Exception occured in getting file path -" + ex.Message);
                throw;
            }
        }
    }
}
