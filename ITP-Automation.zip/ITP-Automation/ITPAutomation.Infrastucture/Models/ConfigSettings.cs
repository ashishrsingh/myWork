﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.Infrastucture.Models
{
    public class ConfigSettings
    {
        public string KeyVaultName { get; set; }
        public string MongoDBSecretName { get; set; }
        
        public string TenantId { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }
        public string MongoDataBaseName { get; set; }
        public string CollectionName { get; set; }
        public string blobConnectionSecretName { get; set; }
    public int MongoDownTime { get; set; }
    }
}
