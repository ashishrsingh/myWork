﻿using MongoDB.Bson;
using MongoDB.Driver;

namespace ITPAutomation.API
{
    public class MongoDBUtility
    {
        public IMongoDatabase ConnectToMongoDB(string connectionString, string databaseName)
        {
            var client = new MongoClient(connectionString);
            return client.GetDatabase(databaseName);
        }
      
        public BsonDocument FetchPickupLocation(IMongoDatabase database, string referenceId, string collectionName)
        {
            var collection = database.GetCollection<BsonDocument>(collectionName);
            var filter = Builders<BsonDocument>.Filter.Eq("referenceId", referenceId);
            var projection = Builders<BsonDocument>.Projection.Include("pickupLocation").Exclude("_id");
            return collection.Find(filter).Project<BsonDocument>(projection).FirstOrDefault();
        }

        public BsonDocument FetchDeliveryLocation(IMongoDatabase database, string referenceId, string collectionName)
        {
            var collection = database.GetCollection<BsonDocument>(collectionName);
            var filter = Builders<BsonDocument>.Filter.Eq("referenceId", referenceId);
            var projection = Builders<BsonDocument>.Projection.Include("deliveryLocation").Exclude("_id");
            return collection.Find(filter).Project<BsonDocument>(projection).FirstOrDefault();
        }

        public BsonDocument FetchDeliveryTimeSlot(IMongoDatabase database, string referenceId, string collectionName)
        {
            var collection = database.GetCollection<BsonDocument>(collectionName);
            var filter = Builders<BsonDocument>.Filter.Eq("referenceId", referenceId);
            var projection = Builders<BsonDocument>.Projection.Include("deliveryTimeSlot").Exclude("_id");
            return collection.Find(filter).Project<BsonDocument>(projection).FirstOrDefault();
        }
    }
}