﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using ITPAutomation.Infrastucture.Models;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class RunHistory : EntityBase
    {

        [JsonProperty("fileName")]
        [BsonElement("fileName")]
        public string fileName { get; set; }

        [JsonProperty("sequence")]
        [BsonElement("sequence")]
        public int sequence { get; set; }

        [JsonProperty("createdAt")]
        [BsonElement("createdAt")]
        public DateTime? createdAt { get; set; }

        [JsonProperty("expireAt")]
        [BsonElement("expireAt")]
        public DateTime? expireAt { get; set; }



        [JsonProperty("noOfDocuments")]
        [BsonElement("noOfDocuments")]
        public int noOfDocuments { get; set; }


        [JsonProperty("status")]
        [BsonElement("status")]
        public int status { get; set; }

        [JsonProperty("planID")]
        [BsonElement("planID")]
        public string planID { get; set; }

        [JsonProperty("action")]
        [BsonElement("action")]
        public string action { get; set; }

        [JsonProperty("noOfDocumentsCreated")]
        [BsonElement("noOfDocumentsCreated")]
        public int noOfDocumentsCreated   { get; set; }

        [JsonProperty("noOfDocumentsDeleted")]
        [BsonElement("noOfDocumentsDeleted")]
        public int noOfDocumentsDeleted { get; set; }

        [JsonProperty("noOfDocumentsUpdated")]
        [BsonElement("noOfDocumentsUpdated")]
        public int noOfDocumentsUpdated { get; set; }


    }
}
