﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class journeyReference
    {
        [JsonProperty("fixedJourneyPairReference")]
        [BsonElement("fixedJourneyPairReference")]
        public string fixedJourneyPairReference { get; set; }

        [JsonProperty("convenienceMainChain")]
        [BsonElement("convenienceMainChain")]
        public int convenienceMainChain { get; set; }

        [JsonProperty("fixedJourneySequence")]
        [BsonElement("fixedJourneySequence")]
        public int fixedJourneySequence { get; set; }

        [JsonProperty("fixedJourneyPredefinedTripCode")]
        [BsonElement("fixedJourneyPredefinedTripCode")]
        public int fixedJourneyPredefinedTripCode { get; set; }


        [JsonProperty("pickupWindowStartDateTime")]
        [BsonElement("pickupWindowStartDateTime")]
        public DateTime? pickupWindowStartDateTime { get; set; }


        [JsonProperty("pickupWindowEndDateTime")]
        [BsonElement("pickupWindowEndDateTime")]
        public DateTime? pickupWindowEndDateTime { get; set; }

        [JsonProperty("pickupTargetDateTime")]
        [BsonElement("pickupTargetDateTime")]
        public DateTime? pickupTargetDateTime { get; set; }

        [JsonProperty("deliveryWindowStartDateTime")]
        [BsonElement("deliveryWindowStartDateTime")]
        public DateTime? deliveryWindowStartDateTime { get; set; }

        [JsonProperty("deliveryWindowEndDateTime")]
        [BsonElement("deliveryWindowEndDateTime")]
        public DateTime? deliveryWindowEndDateTime { get; set; }

        [JsonProperty("deliveryTargetDateTime")]
        [BsonElement("deliveryTargetDateTime")]
        public DateTime? deliveryTargetDateTime { get; set; }

        [JsonProperty("destinationYardArea")]
        [BsonElement("destinationYardArea")]
        public string destinationYardArea { get; set; }

        [JsonProperty("loadUnloadTimeInSeconds")]
        [BsonElement("loadUnloadTimeInSeconds")]
        public int loadUnloadTimeInSeconds { get; set; }

        [JsonProperty("fixedLoadTimeInSeconds")]
        [BsonElement("fixedLoadTimeInSeconds")]
        public int fixedLoadTimeInSeconds { get; set; }

        [JsonProperty("trailerAccount")]
        [BsonElement("trailerAccount")]
        public string trailerAccount { get; set; }

        [JsonProperty("journeySiteInfo1")]
        [BsonElement("journeySiteInfo1")]
        public string journeySiteInfo1 { get; set; }

        [JsonProperty("journeySiteInfo2")]
        [BsonElement("journeySiteInfo2")]
        public string journeySiteInfo2 { get; set; }

        [JsonProperty("journeySiteInfo3")]
        [BsonElement("journeySiteInfo3")]
        public string journeySiteInfo3 { get; set; }

        [JsonProperty("journeySiteInfo4")]
        [BsonElement("journeySiteInfo4")]
        public string journeySiteInfo4 { get; set; }

        [JsonProperty("deliveryStartDateTime")]
        [BsonElement("deliveryStartDateTime")]
        public DateTime? deliveryStartDateTime { get; set; }

        [JsonProperty("deliveryEndDateTime")]
        [BsonElement("deliveryEndDateTime")]
        public DateTime? deliveryEndDateTime { get; set; }

    }
}
