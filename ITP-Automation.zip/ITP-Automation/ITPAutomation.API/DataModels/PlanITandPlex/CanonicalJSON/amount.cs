﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class amount
    {
        [JsonProperty("uom")]
        [BsonElement("uom")]
        public string uom { get; set; }

        [JsonProperty("value")]
        [BsonElement("value")]
        public Double value { get; set; }
    }
}
