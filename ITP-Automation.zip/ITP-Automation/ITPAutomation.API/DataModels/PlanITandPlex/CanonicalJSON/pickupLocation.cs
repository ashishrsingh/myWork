﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class pickupLocation
    {
        [JsonProperty("_id")]
        [BsonElement("_id")]
        public string id { get; set; }

        [JsonProperty("type")]
        [BsonElement("type")]
        public string type { get; set; }

        [JsonProperty("name")]
        [BsonElement("name")]
        public string name { get; set; }
    }
}
