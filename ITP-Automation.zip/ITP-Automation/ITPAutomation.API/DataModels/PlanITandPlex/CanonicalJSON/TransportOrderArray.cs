﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
   public sealed class TransportOrderArray
    {
        [JsonProperty("transportOrder")]
        [BsonElement("transportOrder")]
        public transportOrder[] transportOrder { get; set; }
    }
}
