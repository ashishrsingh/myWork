﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using ITPAutomation.DataModels.PlanIT.CanonicalJSON;

namespace ITPAutomation.DataModels
{
    public class mongoDbClass
    {
        //public mongoDbClass();

        [BsonElement("TransportOrder")]
        [JsonProperty("TransportOrder")]
        public transportOrder TransportOrder { get; set; }
    }
}
