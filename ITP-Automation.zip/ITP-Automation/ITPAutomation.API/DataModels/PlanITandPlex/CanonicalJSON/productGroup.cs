﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class productGroup
    {
        [JsonProperty("type")]
        [BsonElement("type")]
        public string type { get; set; }

        [JsonProperty("amount")]
        [BsonElement("amount")]
        public amount[] amount { get; set; }

        [JsonProperty("productSubGroup")]
        [BsonElement("productSubGroup")]
        public productSubGroup[] productSubGroup { get; set; }
    }
}
