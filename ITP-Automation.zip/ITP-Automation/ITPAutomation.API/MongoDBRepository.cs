﻿using ITPAutomation.Infrastucture.Models;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System.Diagnostics;
using System.Globalization;

namespace ITPAutomation
{
    public class MongoDbRepository<TEntity> : IDisposable where TEntity : EntityBase
    {
        private readonly IMongoDatabase _database = null;
        protected MongoClient _client = null;
        private IMongoCollection<TEntity> collection;
        private bool disposed = false;
        public static IConfiguration Configuration { get; set; }
        private static string MongoConnectionString;
        public static string MongoDataBaseName;
        private static string CollectionName;
        public MongoDbRepository()
        {
#if DEBUG
            var config = new ConfigurationBuilder()
                 .AddJsonFile($"appsettings.dev.json", optional: false, reloadOnChange: true)
                .AddUserSecrets(typeof(hooks).Assembly)
                .AddEnvironmentVariables()
                .Build();
#else
            var config = new ConfigurationBuilder()
                 .AddJsonFile($"appsettings.json", optional: false, reloadOnChange: true)
                .AddUserSecrets(typeof(hooks).Assembly)
                .AddEnvironmentVariables()
                .Build();
#endif
            MongoConnectionString = config.GetValue<string>("MongoConnectionString");
            MongoDataBaseName = config.GetValue<string>("MongoDBdatabaseName");
            CollectionName = config.GetValue<string>("MongoDBCollectionName");
            _client = new MongoClient(MongoConnectionString);
            _database = _client.GetDatabase(MongoDataBaseName);
            GetCollection(CollectionName);//dbsettings collection
        }

        public ICollection<TEntity> FindAll(int sequenceId, DateTime createdDate, String source)
        {
            var sort = Builders<TEntity>.Sort.Descending("_id");
            var filter1 = Builders<TEntity>.Filter.Gt("createdAt", createdDate);
            var filter2 = Builders<TEntity>.Filter.Eq("sequenceId", sequenceId);
            var filter3 = Builders<TEntity>.Filter.Eq("source", source);

            return collection.Find(filter1 & filter2 & filter3).ToList();
        }
        public ICollection<TEntity> RunFindAll()
        {
            var sort = Builders<TEntity>.Sort.Descending("createdAt");
            //var filter1 = Builders<TEntity>.Filter.Empty;
            //var filter2 = Builders<TEntity>.Filter.Eq("value", "myValue");
            // FilterDefinition<TEntity> nameFilter = Builders<TEntity>.Filter.Eq(x => x.sequenceId, "Justine Picardie");

            return collection.Find(_ => true).Sort(sort).Limit(1).ToList();
            //return collection.Find(_ => true).ToList();

        }

        private void GetCollection(string collectionName)
        {
            if (!string.IsNullOrEmpty(collectionName))
            {
                collection = _database.GetCollection<TEntity>(collectionName);
            }
            else
            {
                collection = _database.GetCollection<TEntity>(typeof(TEntity).Name);
            }
        }
        private MongoClient SetConnectionString(string MongoDBConnectionString, int MongoDownTime)
        {
            int count = 0;
            Debug.WriteLine($"SetConnectionString started at :{DateTime.UtcNow}");
            try
            {
                if (this._client == null)
                {
                    count++;
                    var clientSettings = MongoClientSettings.FromConnectionString((MongoDBConnectionString));
                    clientSettings.MaxConnectionIdleTime = new TimeSpan(0, 0, 59);
                    clientSettings.ServerSelectionTimeout = TimeSpan.FromSeconds(MongoDownTime);
                    clientSettings.MaxConnectionPoolSize = 500;
                    clientSettings.AllowInsecureTls = false;
                    this._client = new MongoClient(clientSettings);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"{DateTime.UtcNow.ToString("yyyy-MM-dd hh:mm:ss tt", CultureInfo.InvariantCulture)} - Message not inserted in MongoDb, due to exception.{ex.Message}");
            }
            Debug.WriteLine($"SetConnectionString completed at :{DateTime.UtcNow}");
            return this._client;
        }

        public bool DeleteAll()
        {
            bool result = false;
            try
            {
                collection.DeleteMany("{}");
                result = true;
            }
            catch (MongoException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    // Dispose managed resources.
                    this._client.Cluster.Dispose();
                }
                disposed = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
