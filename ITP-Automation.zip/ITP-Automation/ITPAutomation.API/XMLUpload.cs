﻿using Azure.Identity;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using ITPAutomation.Infrastucture;
using ITPAutomation.Infrastucture.Models;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;
using System.Diagnostics;

namespace ITPAutomation
{
    class XMLUpload
    {
        readonly AppSettings _appSettings;
        public IConfiguration Configuration { get; set; }
        private string BlobConnectionString;

        public void GetConfigValues()
        {
#if DEBUG
            var config = new ConfigurationBuilder()
                 .AddJsonFile($"appsettings.dev.json", optional: false, reloadOnChange: true)
                .AddUserSecrets(typeof(hooks).Assembly)
                .AddEnvironmentVariables()
                .Build();
#else
            var config = new ConfigurationBuilder()
                 .AddJsonFile($"appsettings.json", optional: false, reloadOnChange: true)
                .AddUserSecrets(typeof(hooks).Assembly)
                .AddEnvironmentVariables()
                .Build();
#endif
            BlobConnectionString = config.GetValue<string>("BlobConnectionString");
        }

        public XMLUpload()
        {
            GetConfigValues();
        }
        private static ClientSecretCredential GetCredentials(string tenantId, string clientId, string clientsecret)
        {
            ClientSecretCredential clientSecretCredentials = new ClientSecretCredential(tenantId, clientId, clientsecret);
            return clientSecretCredentials;
        }

        public IWebDriver driver;

        public void UploadFileToAzureBlob(string containerName, string blobPath, string fileName, string filepath)
        {
            try
            {
                // Get a reference to a container named "sample-container" and then create it
                BlobContainerClient container = new BlobContainerClient(BlobConnectionString, containerName);
                BlobClient blobClient = container.GetBlobClient(blobPath + '/' + fileName);
                System.IO.FileStream objFStream = System.IO.File.OpenRead(filepath);

                blobClient.Upload(objFStream);
                objFStream.Close();
                objFStream.Dispose();
                Thread.Sleep(5000);
            }
            catch (Exception e)
            {
                Debug.WriteLine(
                    "Unknown encountered on server. Message:'{0}' when writing an object", e.Message);
                Debug.WriteLine(
                    "Unknown encountered on server. Message:'{0}' when writing an object", e.StackTrace);
            }
        }

        public async Task<bool> CheckAzureBlob(string fileName, string folder)
        {
            BlobServiceClient blobServiceClient = new BlobServiceClient(BlobConnectionString);
            BlobContainerClient containerClient = blobServiceClient.GetBlobContainerClient(ITPConstant.PlanITcontainerName);
            await foreach (BlobItem blobItem in containerClient.GetBlobsAsync(prefix: folder + "/"))
            {
                if (blobItem.Name.Contains(fileName))
                { return true; }
            }
            return false;
        }
    }
}
