﻿//using Azure.Core;
//using Azure.Identity;
//using Azure.Security.KeyVault.Secrets;
//using Azure.Storage.Blobs;
//using Azure.Storage.Blobs.Models;
 
//using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities;
//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using ITPAutomation.Infrastucture;

//namespace ITPAutomation.Utility.Helpers
//{
//    public class ITPAzureHelper
//    {
//        public static string blobConnectionString = GetSecret(ITPConstant.testKeyVaultName, ITPConstant.blobConnectionStringSecret);
//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="keyVaultName"></param>
//        /// <param name="secretKey"></param>
//        /// <returns> string connection value</returns>
//        public static string GetSecret(string keyVaultName, string secretKey)
//        {
//            try
//            {
//                var secretClient = SetupSecretClient(keyVaultName);

//                if (secretClient != null)
//                {
//                    if (!string.IsNullOrWhiteSpace(secretKey))
//                    {
//                        //ITPConstant.blobConnectionString = secretClient.GetSecret(secretKey)?.Value?.Value;
//                        return secretClient.GetSecret(secretKey)?.Value?.Value;
//                    }
                       
//                    else
//                        throw new Exception("Secret Key is Null or empty");
//                }
//                else
//                    throw new Exception("Secret Client is Null or empty");

//            }
//            catch (Exception)
//            {
//                throw;
//            }
//        }

//        /// <summary>
//        /// 
//        /// </summary>
//        /// <param name="keyVaultName"></param>
//        /// <returns> SecretClient </returns>
//        /// <exception cref="Exception"></exception>
//        private static SecretClient SetupSecretClient(string keyVaultName)
//        {
//            if (!string.IsNullOrEmpty(keyVaultName))
//            {
//                SecretClientOptions secretClientOptions = new()
//                {
//                    Retry = {
//                        Delay = TimeSpan.FromSeconds(2),
//                        MaxDelay = TimeSpan.FromSeconds(10),
//                        MaxRetries = 3,
//                        Mode = RetryMode.Exponential
//                    }
//                };

//                var tenantId = Environment.GetEnvironmentVariable("TENANT_ID");
//                var clientId = Environment.GetEnvironmentVariable("AZ_CLIENT_ID");
//                var clientSecret = Environment.GetEnvironmentVariable("AZ_CLIENT_SECRET");

//                if (!string.IsNullOrEmpty(tenantId) && !string.IsNullOrEmpty(clientId) && !string.IsNullOrEmpty(clientSecret))
//                    return new SecretClient(new Uri($"https://{keyVaultName}.vault.azure.net"),
//                        new ClientSecretCredential(tenantId, clientId, clientSecret),
//                    secretClientOptions);

//                return new SecretClient(new Uri($"https://{keyVaultName}.vault.azure.net"),
//                        new DefaultAzureCredential(), secretClientOptions);
//            }
//            else
//            {
//                throw new Exception("Key Vault Name is empty or null");
//            }
//        }

//        public static bool CheckFileExistInAzureBlob(string containerName, string blobPath, int waitInTimeSecs)
//        {
//            try
//            {
//                BlobContainerClient container = new BlobContainerClient(blobConnectionString, containerName);
//                bool isFileExists = false;
//                var watch = Stopwatch.StartNew();
//                int elapsedSeconds = 0;
//                Console.WriteLine("Checking for blobs...");
//                while (!isFileExists && elapsedSeconds <= waitInTimeSecs)
//                {
//                    var blobList = container.GetBlobs(prefix: blobPath);

//                    // Print out all the blob names
//                    foreach (BlobItem blob in container.GetBlobs(prefix: blobPath))
//                    {
//                        isFileExists = true;
//                        Console.WriteLine("Blob exists with name-" + blob.Name);
//                        //container.DeleteBlob(blob.Name);
//                    }
//                    elapsedSeconds = Convert.ToInt16(watch.Elapsed.TotalSeconds);
//                }
//                return isFileExists;
//            }
//            catch (Exception e)
//            {
//                Console.WriteLine(
//                    "Unknown encountered on server. Message:'{0}' when writing an object", e.Message);
//                Console.WriteLine(
//                    "Unknown encountered on server. Message:'{0}' when writing an object", e.StackTrace);
//                throw e;
//            }

//        }
//    }
//}
