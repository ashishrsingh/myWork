﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ITPAutomation.DataModels.PlanIT.ORDDataModel
{
    public class ORDXMLDataModel
    {
        [XmlRoot(ElementName = "comtec")]
        public class comtec
        {
            [XmlElement(ElementName = "transport_orders")]
            public transport_orders transport_orders { get; set; }

            [XmlAttribute(AttributeName = "ns", Namespace = "http://www.w3.org/2001/XMLSchema")]
            public string Ns { get; set; }


        }

        [XmlRoot(ElementName = "transport_orders")]
        public class transport_orders
        {
            [XmlElement(ElementName = "transport_order")]
            public List<transport_order> transport_order { get; set; }
        }

        [XmlRoot(ElementName = "transport_order")]
        public class transport_order
        {
            [XmlElement(ElementName = "id")]
            public string id { get; set; }

            [XmlElement(ElementName = "order_number")]
            public string order_number { get; set; }

            [XmlElement(ElementName = "order_line_number")]
            public string order_line_number { get; set; }

            [XmlElement(ElementName = "order_date")]
            public string order_date { get; set; }

            [XmlElement(ElementName = "order_kind_code")]
            public string order_kind_code { get; set; }

            [XmlElement(ElementName = "order_status")]
            public order_status order_status { get; set; }

            [XmlElement(ElementName = "contactId")]
            public string contactId { get; set; }

            [XmlElement(ElementName = "productId")]
            public string productId { get; set; }

            [XmlElement(ElementName = "product_description")]
            public string product_description { get; set; }

            [XmlElement(ElementName = "amounts")]
            public amounts amounts { get; set; }

            [XmlElement(ElementName = "department_code")]
            public string department_code { get; set; }

            [XmlElement(ElementName = "companyId")]
            public string companyId { get; set; }

            [XmlElement(ElementName = "suborders")]
            public suborders suborders { get; set; }

            [XmlElement(ElementName = "udfields")]
            public udfields udfields { get; set; }

            [XmlElement(ElementName = "pickup_task")]
            public pickup_task pickup_task { get; set; }

            [XmlElement(ElementName = "delivery_task")]
            public delivery_task delivery_task { get; set; }

        }

        [XmlRoot(ElementName = "order_status")]
        public class order_status
        {
            [XmlElement(ElementName = "code")]
            public string code { get; set; }

        }

        [XmlRoot(ElementName = "amounts")]
        public class amounts
        {
            [XmlElement(ElementName = "amount")]
            public List<amount> amount { get; set; }

        }

        [XmlRoot(ElementName = "amount")]
        public class amount
        {
            [XmlElement(ElementName = "unit_code")]
            public string unit_code { get; set; }

            [XmlElement(ElementName = "value")]
            public string value { get; set; }

        }

        [XmlRoot(ElementName = "suborders")]
        public class suborders
        {
            [XmlElement(ElementName = "suborder")]
            public List<suborder> suborder { get; set; }

        }

        [XmlRoot(ElementName = "suborder")]
        public class suborder
        {
            [XmlElement(ElementName = "code")]
            public string code { get; set; }

            [XmlElement(ElementName = "productId")]
            public string productId { get; set; }

            [XmlElement(ElementName = "suborder_description")]
            public string suborder_description { get; set; }

            [XmlElement(ElementName = "amounts")]
            public amounts amounts { get; set; }
        }

        [XmlRoot(ElementName = "udfields")]
        public class udfields
        {
            [XmlElement(ElementName = "udfield")]
            public List<udfield> udfield { get; set; }

        }

        [XmlRoot(ElementName = "udfield")]
        public class udfield
        {
            [XmlAttribute(AttributeName = "name")]
            public string name { get; set; }
            [XmlText]
            public string Text { get; set; }
        }

        [XmlRoot(ElementName = "pickup_task")]
        public class pickup_task
        {
            [XmlElement(ElementName = "addressId")]
            public string addressId { get; set; }

            [XmlElement(ElementName = "start_window")]
            public start_window start_window { get; set; }

            [XmlElement(ElementName = "duration")]
            public string duration { get; set; }

            [XmlElement(ElementName = "reference", IsNullable = true)]
            public string reference { get; set; }

            [XmlElement(ElementName = "timeslots")]
            public timeslots timeslots { get; set; }

            [XmlElement(ElementName = "capabilities")]
            public capabilities capabilities { get; set; }

        }

        [XmlRoot(ElementName = "start_window")]
        public class start_window
        {
            [XmlElement(ElementName = "from_instant")]
            public string from_instant { get; set; }

            [XmlElement(ElementName = "till_instant")]
            public string till_instant { get; set; }
        }

        [XmlRoot(ElementName = "timeslots")]
        public class timeslots
        {
            [XmlElement(ElementName = "timeslot")]
            public List<timeslot> timeslot { get; set; }

        }

        [XmlRoot(ElementName = "timeslot")]
        public class timeslot
        {
            [XmlElement(ElementName = "id")]
            public string id { get; set; }

            [XmlElement(ElementName = "day_of_week")]
            public string day_of_week { get; set; }

            [XmlElement(ElementName = "from_time")]
            public string from_time { get; set; }

            [XmlElement(ElementName = "till_time")]
            public string till_time { get; set; }

            [XmlElement(ElementName = "notAllowedResourceKinds")]
            public notAllowedResourceKinds notAllowedResourceKinds { get; set; }

        }

        [XmlRoot(ElementName = "notAllowedResourceKinds")]
        public class notAllowedResourceKinds
        {
            [XmlElement(ElementName = "resourceKindCode")]
            public List<resourceKindCode> resourceKindCode { get; set; }

        }

        [XmlRoot(ElementName = "resourceKindCode")]
        public class resourceKindCode
        {
            [XmlText]
            public string Text { get; set; }
        }

        [XmlRoot(ElementName = "capabilities")]
        public class capabilities
        {
            [XmlElement(ElementName = "capability")]
            public List<capability> capability { get; set; }

        }

        [XmlRoot(ElementName = "capability")]
        public class capability
        {
            [XmlElement(ElementName = "code")]
            public string code { get; set; }

            [XmlElement(ElementName = "name")]
            public string name { get; set; }

            [XmlElement(ElementName = "required")]
            public string required { get; set; }
        }

        [XmlRoot(ElementName = "delivery_task")]
        public class delivery_task
        {
            [XmlElement(ElementName = "addressId")]
            public string addressId { get; set; }

            [XmlElement(ElementName = "start_window")]
            public start_window start_window { get; set; }

            [XmlElement(ElementName = "duration")]
            public string duration { get; set; }

            [XmlElement(ElementName = "reference", IsNullable = true)]
            public string reference { get; set; }

            [XmlElement(ElementName = "timeslots")]
            public timeslots timeslots { get; set; }

            [XmlElement(ElementName = "capabilities")]
            public capabilities capabilities { get; set; }

        }
    }
}
