﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using ITPAutomation.Infrastucture.Models;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON  
{
    public sealed class transportOrder : EntityBase
    {

        [JsonProperty("createdAt")]
        [BsonElement("createdAt")]
        public DateTime? createdAt { get; set; }

        [JsonProperty("transportOrderId")]
        [BsonElement("transportOrderId")]
        public string transportOrderId { get; set; }

        [JsonProperty("publishId")]
        [BsonElement("publishId")]
        public string publishId { get; set; }

        [JsonProperty("sequenceId")]
        [BsonElement("sequenceId")]
        public Int32 SequenceId { get; set; }

        [JsonProperty("source")]
        [BsonElement("source")]
        public string source { get; set; }

        [JsonProperty("referenceId")]
        [BsonElement("referenceId")]
        public string referenceID { get; set; }

        [JsonProperty("type")]
        [BsonElement("type")]
        public string type { get; set; }

        [JsonProperty("orderReceiptDateTime")]
        [BsonElement("orderReceiptDateTime")]
        public DateTime? orderReceiptDateTime { get; set; }

        [JsonProperty("depotPlannedDateTime")]
        [BsonElement("depotPlannedDateTime")]
        public DateTime? depotPlannedDateTime { get; set; }

        [JsonProperty("status")]
        [BsonElement("status")]
        public string status { get; set; }

        [JsonProperty("brand")]
        [BsonElement("brand")]
        public string brand { get; set; }

        [JsonProperty("amount")]
        [BsonElement("amount")]
        public amount[] amount { get; set; }

        [JsonProperty("productGroup")]
        [BsonElement("productGroup")]
        public productGroup[] productGroup { get; set; }

        [JsonProperty("pickupLocation")]
        [BsonElement("pickupLocation")]
        public pickupLocation pickupLocation { get; set; }

        [JsonProperty("deliveryLocation")]
        [BsonElement("deliveryLocation")]
        public deliveryLocation deliveryLocation { get; set; }


        [JsonProperty("trunkLocation")]
        [BsonElement("trunkLocation")]
        public trunkLocation trunkLocation { get; set; }

        [JsonProperty("orderReference")]
        [BsonElement("orderReference")]
        public orderReference orderReference { get; set; }


        [JsonProperty("journeyReference")]
        [BsonElement("journeyReference")]
        public journeyReference journeyReference { get; set; }

        [JsonProperty("pickupTimeSlot")]
        [BsonElement("pickupTimeSlot")]
        public pickupTimeSlot pickupTimeSlot { get; set; }

        [JsonProperty("deliveryTimeSlot")]
        [BsonElement("deliveryTimeSlot")]
        public deliveryTimeSlot deliveryTimeSlot { get; set; }

    }
}
