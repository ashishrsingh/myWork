﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class deliveryLocation
    {
        [JsonProperty("id")]
        [BsonElement("id")]
        public string id { get; set; }

        [JsonProperty("type")]
        [BsonElement("type")]
        public string type { get; set; }

        [JsonProperty("name")]
        [BsonElement("name")]
        public string name { get; set; }
    }
}