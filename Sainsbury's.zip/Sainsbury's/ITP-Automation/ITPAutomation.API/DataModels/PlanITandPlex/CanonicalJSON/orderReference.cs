﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class orderReference
    {
        [JsonProperty("orderSlotType")]
        [BsonElement("orderSlotType")]
        public string orderSlotType { get; set; }

        [JsonProperty("earliestDespatchDateTime")]
        [BsonElement("earliestDespatchDateTime")]
        public DateTime? earliestDespatchDateTime { get; set; }

        [JsonProperty("latestDespatchDateTime")]
        [BsonElement("latestDespatchDateTime")]
        public DateTime? latestDespatchDateTime { get; set; }

        [JsonProperty("transportComment")]
        [BsonElement("transportComment")]
        public string transportComment { get; set; }

        [JsonProperty("warehouseComment")]
        [BsonElement("warehouseComment")]
        public string warehouseComment { get; set; }

        [JsonProperty("destinationComment")]
        [BsonElement("destinationComment")]
        public string destinationComment { get; set; }

        [JsonProperty("otherComment")]
        [BsonElement("otherComment")]
        public string otherComment { get; set; }

        [JsonProperty("isTrunk")]
        [BsonElement("isTrunk")]
        public bool isTrunk { get; set; }

        [JsonProperty("owningDepot")]
        [BsonElement("owningDepot")]
        public string owningDepot { get; set; }

        [JsonProperty("orderType")]
        [BsonElement("orderType")]
        public string orderType { get; set; }

        [JsonProperty("primaryReference")]
        [BsonElement("primaryReference")]
        public string primaryReference { get; set; }

    }
}