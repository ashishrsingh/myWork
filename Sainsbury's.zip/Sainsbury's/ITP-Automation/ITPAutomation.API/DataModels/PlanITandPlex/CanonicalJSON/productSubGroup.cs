﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class productSubGroup
    {
        [JsonProperty("type")]
        [BsonElement("type")]
        public string type { get; set; }

        [JsonProperty("amount")]
        [BsonElement("amount")]
        public amount[] amount { get; set; }

    }
}
