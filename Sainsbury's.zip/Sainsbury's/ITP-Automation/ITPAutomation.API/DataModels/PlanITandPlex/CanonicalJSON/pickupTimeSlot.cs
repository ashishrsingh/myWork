﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.DataModels.PlanIT.CanonicalJSON
{
    public sealed class pickupTimeSlot
    {
        [JsonProperty("timeSlotId")]
        [BsonElement("timeSlotId")]
        public string timeSlotId { get; set; }

        [JsonProperty("earliestDay")]
        [BsonElement("earliestDay")]
        public Int32? earliestDay { get; set; }

        [JsonProperty("latestDay")]
        [BsonElement("latestDay")]
        public Int32? latestDay { get; set; }

        [JsonProperty("earliestTime")]
        [BsonElement("earliestTime")]
        public string earliestTime { get; set; }


        [JsonProperty("latestTime")]
        [BsonElement("latestTime")]
        public string latestTime { get; set; }

        [JsonProperty("notAllowedResourceKindCode")]
        [BsonElement("notAllowedResourceKindCode")]
        public string[] notAllowedResourceKindCode { get; set; }

        [JsonProperty("resourceKinds")]
        [BsonElement("resourceKinds")]
        public string resourceKinds { get; set; }

        [JsonProperty("subContractors")]
        [BsonElement("subContractors")]
        public string[] subContractors { get; set; }
    }
}
