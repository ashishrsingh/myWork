﻿using MongoDB.Bson.Serialization.Attributes;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.DataModels
{
    public class ordrequest
    {
        [BsonElement("sequenceId")]
        [JsonProperty("sequenceId")]
        public Int32 sequenceId { get; set; }

        [BsonElement("createdAt")]
        [JsonProperty("createdAt")]
        public string createdAt { get; set; }
    }
}
