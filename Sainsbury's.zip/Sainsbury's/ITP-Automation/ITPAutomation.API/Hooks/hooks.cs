﻿using ITPAutomation.DataModels;
using Microsoft.VisualStudio.TestPlatform.ObjectModel;
using Newtonsoft.Json;
//using OpenQA.Selenium;
//using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading;
using TechTalk.SpecFlow;
using ITPAutomation.DataModels.PlanIT.CanonicalJSON;
using ITPAutomation;
using ITPAutomation.Infrastucture.Models;
using ITPAutomation.Infrastucture;

namespace ITPAutomation
{
    [Binding]
    public class hooks
    {
        private MongoDbRepository<transportOrder> daReadModel;
        private MongoDbRepository<RunHistory> RunHistorydaReadModel;
        private MongoDbRepository<RunHistory> RunHistorydaReadModelforPlex;

        private ScenarioContext _scenarioContext;
        public hooks(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;

            //ConfigSettings dBSettings = new ConfigSettings()
            //{
            //    MongoDataBaseName = ITPConstant.MongoDBdatabaseName,
                
            //    CollectionName = ITPConstant.MongoDBCollectionName,
            //    KeyVaultName = ITPConstant.KeyVaultName,

            //    TenantId = ITPConstant.TenantId,
            //    MongoDBSecretName = ITPConstant.MongoDBSecretName,
            //    ClientId = ITPConstant.ClientId,
            //    ClientSecret = ITPConstant.ClientSecret,
            //    MongoDownTime = 5
            //};

            //ConfigSettings dBSettings1 = new ConfigSettings()
            //{
            //    MongoDataBaseName = ITPConstant.MongoDBdatabaseName,
 
            //    CollectionName = ITPConstant.MongoDBRunHistoryCollectionName,

            //    MongoDownTime = 5,
            //      KeyVaultName = ITPConstant.KeyVaultName,

            //    TenantId = ITPConstant.TenantId,
            //    MongoDBSecretName = ITPConstant.MongoDBSecretName,
            //    ClientId = ITPConstant.ClientId,
            //    ClientSecret = ITPConstant.ClientSecret
            //};
            //ConfigSettings dBSettings2 = new ConfigSettings()
            //{
            //    MongoDataBaseName = ITPConstant.MongoDBdatabaseName,
                
            //    CollectionName = ITPConstant.Plex_MongoDBRunHistoryCollectionName,

            //    MongoDownTime = 5,
            //      KeyVaultName = ITPConstant.KeyVaultName,

            //    TenantId = ITPConstant.TenantId,
            //    MongoDBSecretName = ITPConstant.MongoDBSecretName,
            //    ClientId = ITPConstant.ClientId,
            //    ClientSecret = ITPConstant.ClientSecret
            //};
            daReadModel = new MongoDbRepository<transportOrder>();
            RunHistorydaReadModel = new MongoDbRepository<RunHistory>();
            RunHistorydaReadModelforPlex = new MongoDbRepository<RunHistory>();

        }

        //[BeforeFeature]
        //public static void BeforeFeature()
        //{
        //    if (File.Exists(ITPConstant.testLogFileLocal))
        //        File.Delete(ITPConstant.testLogFileLocal);
        //    File.AppendAllText(ITPConstant.testLogFileLocal, "PlantIt and Plex Integration Result " + Environment.NewLine + "Start Date Time: " + DateTime.Now.ToString() + Environment.NewLine + Environment.NewLine
        //        + "Detailed Report " + Environment.NewLine + "=======================================================" + Environment.NewLine);

        //}


        //[BeforeScenario]
        //public void BeforeScenario()
        //{

        //    if (Directory.Exists(ITPConstant.JSONOutputFolderPath))
        //    {
        //        string[] s3files = System.IO.Directory.GetFiles(ITPConstant.JSONOutputFolderPath);
        //        foreach (string file in s3files)
        //        {
        //            File.Delete(file);
        //        }
        //    }
        //    else
        //    {
        //        Directory.CreateDirectory(ITPConstant.JSONOutputFolderPath);
        //    }

        //    if (Directory.Exists(ITPConstant.tctdplanitfile))
        //    {
        //        string[] s3files = System.IO.Directory.GetFiles(ITPConstant.tctdplanitfile);
        //        foreach (string file in s3files)
        //        {
        //            File.Delete(file);
        //        }
        //    }
        //    else
        //    {
        //        Directory.CreateDirectory(ITPConstant.tctdplanitfile);
        //    }

        //    if (Directory.Exists(ITPConstant.JSONRunHistoryOutputFolderPath))
        //    {
        //        string[] s3files = System.IO.Directory.GetFiles(ITPConstant.JSONRunHistoryOutputFolderPath);
        //        foreach (string file in s3files)
        //        {
        //            File.Delete(file);
        //        }
        //    }
        //    else
        //    {
        //        Directory.CreateDirectory(ITPConstant.JSONRunHistoryOutputFolderPath);
        //    }

        //    if (Directory.Exists(ITPConstant.InputFolderPath))
        //    {
        //        string[] s3files = System.IO.Directory.GetFiles(ITPConstant.InputFolderPath);
        //        foreach (string file in s3files)
        //        {
        //            File.Delete(file);
        //        }
        //    }
        //    else
        //    {
        //        Directory.CreateDirectory(ITPConstant.InputFolderPath);
        //    }

        //    if (Directory.Exists(ITPConstant.JSONActualOutputFolderPath))
        //    {
        //        string[] s3files = System.IO.Directory.GetFiles(ITPConstant.JSONActualOutputFolderPath);
        //        foreach (string file in s3files)
        //        {
        //            File.Delete(file);
        //        }
        //    }
        //    else
        //    {
        //        Directory.CreateDirectory(ITPConstant.JSONActualOutputFolderPath);
        //    }

        //    if (Directory.Exists(ITPConstant.ExpectedORDXMLFile))
        //    {
        //        string[] s3files = System.IO.Directory.GetFiles(ITPConstant.ExpectedORDXMLFile);
        //        foreach (string file in s3files)
        //        {
        //            File.Delete(file);
        //        }
        //    }
        //    else
        //    {
        //        Directory.CreateDirectory(ITPConstant.ExpectedORDXMLFile);
        //    }

        //    if (Directory.Exists(ITPConstant.ActualORDXMLFile))
        //    {
        //        string[] s3files = System.IO.Directory.GetFiles(ITPConstant.ActualORDXMLFile);
        //        foreach (string file in s3files)
        //        {
        //            File.Delete(file);
        //        }
        //    }
        //    else
        //    {
        //        Directory.CreateDirectory(ITPConstant.ActualORDXMLFile);
        //    }

        //}


        public void GetAllMessagesFromReadModel(int waitInSec, int sequenceId,DateTime createdDate,String source, string actualMongoFilePath)
        {
            Thread.Sleep(5000);
            int count = 0;
            var actualOutput = daReadModel.FindAll(sequenceId, createdDate, source);
            if (actualOutput.Count == 0)
            {

                var watch = Stopwatch.StartNew();
                bool isDownloadSuccessful = false;
                int elapsedSeconds = 0;
                while (!isDownloadSuccessful && elapsedSeconds <= waitInSec)
                {
                    try
                    {
                        actualOutput = daReadModel.FindAll(sequenceId, createdDate, source);
                        if (actualOutput.Count > 0)
                        {
                            isDownloadSuccessful = true;
                        }
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine("Exception caught on CheckFileExisit" + ex.Message);
                    }
                    elapsedSeconds = Convert.ToInt16(watch.Elapsed.TotalSeconds);
                }
            }

            //var storeResultJSON = JsonConvert.SerializeObject(actualOutput);
            //File.AppendAllText(actualMongoFilePath + count + ".json", storeResultJSON);
            foreach (var item in actualOutput)
            {
                count++;
                var storeResultJSON = JsonConvert.SerializeObject(item, Formatting.Indented);
                File.AppendAllText(actualMongoFilePath + count + ".json", storeResultJSON);

            }


        }

        public void GetAllRunHistoryMessagesFromReadModel(int waitInSec,string actualMongoFilePath)
        {
            Thread.Sleep(5000);
            int count = 0;
            var actualOutput = RunHistorydaReadModel.RunFindAll();
            if (actualOutput.Count == 0)
            {

                var watch = Stopwatch.StartNew();
                bool isDownloadSuccessful = false;
                int elapsedSeconds = 0;
                while (!isDownloadSuccessful && elapsedSeconds <= waitInSec)
                {
                    try
                    {
                        actualOutput = RunHistorydaReadModel.RunFindAll();
                        if (actualOutput.Count > 0)
                        {
                            isDownloadSuccessful = true;
                        }
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine("Exception caught on CheckFileExisit" + ex.Message);
                    }
                    elapsedSeconds = Convert.ToInt16(watch.Elapsed.TotalSeconds);
                }
            }

            //var storeResultJSON = JsonConvert.SerializeObject(actualOutput);
            //File.AppendAllText(actualMongoFilePath + count + ".json", storeResultJSON);
            foreach (var item in actualOutput)
            {
                count++;
                var storeResultJSON = JsonConvert.SerializeObject(item, Formatting.Indented);
                File.AppendAllText(actualMongoFilePath + count + ".json", storeResultJSON);

            }

        }

        public void GetAllRunHistoryMessagesFromReadModelforPlex(int waitInSec, string actualMongoFilePath)
        {
            Thread.Sleep(5000);
            int count = 0;
            var actualOutput = RunHistorydaReadModelforPlex.RunFindAll();
            if (actualOutput.Count == 0)
            {

                var watch = Stopwatch.StartNew();
                bool isDownloadSuccessful = false;
                int elapsedSeconds = 0;
                while (!isDownloadSuccessful && elapsedSeconds <= waitInSec)
                {
                    try
                    {
                        actualOutput = RunHistorydaReadModel.RunFindAll();
                        if (actualOutput.Count > 0)
                        {
                            isDownloadSuccessful = true;
                        }
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine("Exception caught on CheckFileExisit" + ex.Message);
                    }
                    elapsedSeconds = Convert.ToInt16(watch.Elapsed.TotalSeconds);
                }
            }

            //var storeResultJSON = JsonConvert.SerializeObject(actualOutput);
            //File.AppendAllText(actualMongoFilePath + count + ".json", storeResultJSON);
            foreach (var item in actualOutput)
            {
                count++;
                var storeResultJSON = JsonConvert.SerializeObject(item, Formatting.Indented);
                File.AppendAllText(actualMongoFilePath + count + ".json", storeResultJSON);

            }

        }


    //    [AfterFeature]
    //    public static void AfterFeature()
    //    {
    //        ITPConstant.totalCount = ITPConstant.passedCount + ITPConstant.failedCount;
    //        string msg = Environment.NewLine + "=======================================================" + Environment.NewLine + "Test Summary: " + Environment.NewLine + "=======================================================" + Environment.NewLine;
    //        msg += "Number of Files Compared(Scenarios Tested): " + ITPConstant.totalCount + Environment.NewLine +
    //        "Number of Files Matched(Scenarios Passed): " + ITPConstant.passedCount + Environment.NewLine +
    //        "Number of Files mismatched(Scenarios Failed): " + ITPConstant.failedCount + Environment.NewLine +
    //        "Success Rate : " + Math.Round(((ITPConstant.passedCount / ITPConstant.totalCount) * 100), 2) + "%" + Environment.NewLine +
    //        "End Date Time: " + DateTime.Now.ToString() + Environment.NewLine;
    //        File.AppendAllText(ITPConstant.testLogFileLocal, msg + "---------------------------------------------------" + Environment.NewLine);
    //    }

    }
}
