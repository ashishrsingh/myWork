﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using ITPAutomation.Infrastucture;
using System.Security.Cryptography;
using MongoDB.Bson;
using MongoDB.Driver;
using OfficeOpenXml;
using ITPAutomation.API;

namespace ITPAutomation.API
{
    public class PickupLocationData
    {
        public string Id { get; set; }
        public string Type { get; set; } = "null";
        public string OrderType { get; set; }
        public string Loc { get; set; } = "pickuplocation";
        public string Name { get; set; } = "null";
        public string PlaceId { get; set; }
        public string ReferenceId { get; set; }

        public override string ToString()
        {
            return $"_id: {Id}, type: {Type}, name: {Name}, placeId: {PlaceId}, loc: {Loc}, TDATA02: {ReferenceId}";
        }
    }
    public class DeliveryLocationData
    {
        public string ReferenceId { get; set; }
        public string Id { get; set; }
        public string Name { get; set; }
        public string PlaceId { get; set; }
        public string Loc { get; set; } = "deliveryLocation";

        public override string ToString()
        {
            return $"ReferenceId: {ReferenceId}, ID: {Id}, Name: {Name}, PlaceId: {PlaceId}";
        }
    }
    public class DeliveryTimeSlotData
    {
        public string TimeSlotId { get; set; }
        public string EarliestDay { get; set; }
        public string LatestDay { get; set; }
        public string EarliestTime { get; set; }
        public string LatestTime { get; set; }
        public string ReferenceId { get; set; }
        public string Loc { get; set; } = "deliveryTimeSlot";

        public override string ToString()
        {
            return $"TimeSlotId: {TimeSlotId}, EarliestDay: {EarliestDay}, LatestDay: {LatestDay}, EarliestTime: {EarliestTime}, LatestTime: {LatestTime}";
        }
    }

    public class PickupTimeSlotData
    {
        public string TimeSlotId { get; set; }
        public string EarliestDay { get; set; }
        public string LatestDay { get; set; }
        public string EarliestTime { get; set; }
        public string LatestTime { get; set; }
        public string ReferenceId { get; set; }
        public string Loc { get; set; } = "pickupTimeSlot";

        public override string ToString()
        {
            return $"TimeSlotId: {TimeSlotId}, EarliestDay: {EarliestDay}, LatestDay: {LatestDay}, EarliestTime: {EarliestTime}, LatestTime: {LatestTime}";
        }
    }

    public class XmlDataExtractor
    {
        public PickupLocationData ExtractPickupLocation(string xmlFilePath)
        {
            var doc = XDocument.Load(xmlFilePath);

            var tData02 = doc.Descendants("Value")
                             .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TDATA02")?.Value;

            var typeElement = doc.Descendants("Value")
                                 .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TYPE");

            if (typeElement != null)
            {
                string type = typeElement.Value;

                if (type == "D")
                {
                    var depotId = doc.Descendants("Value")
                                     .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "DEPOTID")?.Value;

                    var placeId = doc.Descendants("Value")
                                     .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "DepotPlaceId")?.Value;

                    return new PickupLocationData
                    {
                        Id = depotId,
                        PlaceId = placeId,
                        OrderType = type,
                        Loc = "pickuplocation",
                        ReferenceId = tData02
                    };
                }
                else if (type == "C")
                {
                    var id = doc.Descendants("Value")
                                .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "ID")?.Value;

                    var name = doc.Descendants("Value")
                                  .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "Name")?.Value;

                    var placeId = doc.Descendants("Value")
                                     .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "LocationPlaceId")?.Value;

                    return new PickupLocationData
                    {
                        Id = id,
                        Name = name,
                        PlaceId = placeId,
                        OrderType = type,
                        Loc = "pickuplocation",
                        ReferenceId = tData02
                    };
                }
                else if (type == "TC")
                {
                    var id = doc.Descendants("Value")
                                .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "ID")?.Value;

                    var name = doc.Descendants("Value")
                                  .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "Name")?.Value;

                    var placeId = doc.Descendants("Value")
                                     .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "LocationPlaceId")?.Value;

                    return new PickupLocationData
                    {
                        Id = id,
                        Name = name,
                        PlaceId = placeId,
                        OrderType = type,
                        Loc = "pickuplocation",
                        ReferenceId = tData02
                    };
                }
                else if (type == "TD")
                {
                    return new PickupLocationData
                    {
                        Id = "null",
                        Name = "null",
                        PlaceId = "null",
                        OrderType = type,
                        Loc = "pickuplocation",
                        ReferenceId = tData02
                    };
                }
            }

            return null;
        }

        public DeliveryLocationData ExtractDeliveryLocation(string xmlFilePath)
        {
            var doc = XDocument.Load(xmlFilePath);

            var referenceId = doc.Descendants("Value")
                                 .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TDATA02")?.Value;

            var typeElement = doc.Descendants("Value")
                                .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TYPE");
            if (typeElement != null)
            {
                string type = typeElement.Value;
                if (type == "D")
                {
                    var deliveryId = doc.Descendants("Value")
                               .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "ID")?.Value;

                    var deliveryName = doc.Descendants("Value")
                                          .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "Name")?.Value;

                    var deliveryPlaceId = doc.Descendants("Value")
                                             .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TDATA04PlaceId")?.Value;

                    return new DeliveryLocationData
                    {
                        ReferenceId = referenceId,
                        Id = deliveryId,
                        Name = deliveryName,
                        PlaceId = deliveryPlaceId
                    };
                }
                else if (type == "C")
                {
                    var deliveryId = doc.Descendants("Value")
                               .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "ID")?.Value;

                    var deliveryName = doc.Descendants("Value")
                                          .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "Name")?.Value;

                    var deliveryPlaceId = doc.Descendants("Value")
                                             .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "DepotPlaceId")?.Value;

                    return new DeliveryLocationData
                    {
                        ReferenceId = referenceId,
                        Id = deliveryId,
                        Name = "null",
                        PlaceId = deliveryPlaceId
                    };
                }
                else if (type == "TC")
                {
                    var deliveryId = doc.Descendants("Value")
                               .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "ID")?.Value;

                    var deliveryName = doc.Descendants("Value")
                                          .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "Name")?.Value;

                    var deliveryPlaceId = doc.Descendants("Value")
                                             .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "DepotPlaceId")?.Value;

                    return new DeliveryLocationData
                    {
                        ReferenceId = referenceId,
                        Id = "null",
                        Name = deliveryName,
                        PlaceId = "null"
                    };
                }
                else if (type == "TD")
                {
                    var deliveryId = doc.Descendants("Value")
                               .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "ID")?.Value;

                    var deliveryName = doc.Descendants("Value")
                                          .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "Name")?.Value;

                    var deliveryPlaceId = doc.Descendants("Value")
                                             .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "LocationPlaceId")?.Value;

                    return new DeliveryLocationData
                    {
                        ReferenceId = referenceId,
                        Id = deliveryId,
                        Name = "null",
                        PlaceId = "null"
                    };
                }
            }

            return null;
        }

        public DeliveryTimeSlotData ExtractDeliveryTimeSlot(string xmlFilePath)
        {
            var doc = XDocument.Load(xmlFilePath);

            var referenceId = doc.Descendants("Value")
                                 .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TDATA02")?.Value;

            var timeSlotId = doc.Descendants("Value")
                                .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TIMESLOTID")?.Value;

            var earliestDay = doc.Descendants("Value")
                                 .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "EARRDAY")?.Value;

            var latestDay = doc.Descendants("Value")
                               .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "LARRDAY")?.Value;

            var earliestTime = doc.Descendants("Value")
                                  .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "EARRTIME")?.Value;

            var latestTime = doc.Descendants("Value")
                                .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "LARRTIME")?.Value;

            string timeSlotIdDay = timeSlotId + "_" + earliestDay;

            return new DeliveryTimeSlotData
            {
                ReferenceId = referenceId,
                TimeSlotId = timeSlotIdDay,
                EarliestDay = earliestDay,
                LatestDay = latestDay,
                EarliestTime = earliestTime,
                LatestTime = latestTime
            };
        }
        public PickupTimeSlotData ExtractPickupTimeSlot(string xmlFilePath)
        {
            var doc = XDocument.Load(xmlFilePath);

            var referenceId = doc.Descendants("Value")
                                 .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TDATA02")?.Value;

            var timeSlotId = doc.Descendants("Value")
                                .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "TIMESLOTID")?.Value;

            var earliestDay = doc.Descendants("Value")
                                 .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "EARRDAY")?.Value;

            var latestDay = doc.Descendants("Value")
                               .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "LARRDAY")?.Value;

            var earliestTime = doc.Descendants("Value")
                                  .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "EARRTIME")?.Value;

            var latestTime = doc.Descendants("Value")
                                .FirstOrDefault(x => (string)x.Attribute("KeywordName") == "LARRTIME")?.Value;

            string timeSlotIdDay = timeSlotId + "_" + earliestDay;

            return new PickupTimeSlotData
            {
                ReferenceId = referenceId,
                TimeSlotId = timeSlotIdDay,
                EarliestDay = earliestDay,
                LatestDay = latestDay,
                EarliestTime = earliestTime,
                LatestTime = latestTime
            };
        }
    }
}