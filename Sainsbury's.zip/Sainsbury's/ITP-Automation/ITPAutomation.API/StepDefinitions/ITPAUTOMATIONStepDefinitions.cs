using ITPAutomation.Infrastucture;
using MongoDB.Driver;
using OfficeOpenXml;
using ITPAutomation.API;

namespace ITPAutomation
{
    [Binding]
    public class ITPAutomationStepDefinitions
    {
        private readonly XMLUpload upload;//upload
        private int scenario = 0;
        private string fileName;
        private string fileNameWOExt;
        private MongoDBUtility _mongoDBUtility;
        private IMongoDatabase _database;
        private ConfigurationHelper _configurationHelper;
        private Dictionary<string, string> _documentData;
        private Dictionary<string, string> _xmlData;
        private readonly XmlDataExtractor _xmlDataExtractor;
        private PickupLocationData _xmlPickupLocationData;
        private PickupLocationData _mongoPickupLocationData;
        private DeliveryLocationData _xmlDeliveryLocationData;
        private DeliveryLocationData _mongoDeliveryLocationData;
        private DeliveryTimeSlotData _xmlDeliveryTimeSlotData;
        private DeliveryTimeSlotData _mongoDeliveryTimeSlotData;
        private PickupTimeSlotData _xmlPickupTimeSlotData;
        private PickupTimeSlotData _mongoPickupTimeSlotData;
        private readonly ExcelUtility _excelUtility;

        public ITPAutomationStepDefinitions(ScenarioContext scenarioContext)
        {
            upload = new XMLUpload();
            _mongoDBUtility = new MongoDBUtility();
            _configurationHelper = new ConfigurationHelper();
            _xmlDataExtractor = new XmlDataExtractor();
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            _excelUtility = new ExcelUtility();
        }

        [Given(@"I have a ""([^""]*)"" PlanIT XML file")]
        public void GivenIHaveAPlanITXMLFile(string type)
        {
            string path = ITPConstant.PlanITXMLSamples+type;
            string[] files = Directory.GetFiles(path);

            if (files.Length == 0)
            {
                Assert.True(false, type+" PlanIT XML file not found");
            }
            fileNameWOExt = Path.GetFileNameWithoutExtension(files[0]);
            fileName = files[0];
        }

        [When(@"I upload the ""([^""]*)"" PlanIT XML file to blob storage")]
        public void WhenIUploadThePlanITXMLFileToBlobStorage(string type)
        {
            string path = ITPConstant.PlanITXMLSamples+type;
            string[] files = Directory.GetFiles(path);
           
            foreach (string file in files)
            {
                upload.UploadFileToAzureBlob(ITPConstant.planITcontainerName, ITPConstant.blobStoragePlanITPath, Path.GetFileName(file), file);
            }
        }

        [Then(@"PlanIT XML file is processed and moved to ""([^""]*)"" folder")]
        public async Task ThenPlanITXMLFileIsProcessedAndMovedToFolder(string folder)
        {
            bool fileExists;
            fileExists = await upload.CheckAzureBlob(fileNameWOExt, folder);
            if (fileExists)
            {
                Assert.True ( true, fileName + " blob found in "+folder+" blob folder");
            }
            else
            {
                Assert.Fail (fileName + " blob not found in " + folder + " blob folder");
            }
        }

        [Given(@"I am Connected to MongoDB")]
        public void GivenIAmConnectedToMongoDB()
        {
            string connectionString = _configurationHelper.GetMongoDBConnectionString();
            string databaseName = _configurationHelper.GetMongoDBDatabaseName();
            _database = _mongoDBUtility.ConnectToMongoDB(connectionString, databaseName);
        }

        [When(@"I read the Pickup Location data from MongoDB")]
        public void GivenIFetchThePickupLocationDataFromMongoDBForPlanID()
        {
            string collectionName = _configurationHelper.GetMongoDBCollectionName();
            var bsonDocument = _mongoDBUtility.FetchPickupLocation(_database, _xmlPickupLocationData.ReferenceId, collectionName);
            if (bsonDocument != null)
            {
                _mongoPickupLocationData = new PickupLocationData
                {
                    Id = bsonDocument["pickupLocation"]["_id"].IsBsonNull ? "null" : bsonDocument["pickupLocation"]["_id"].AsString,
                    Type = bsonDocument["pickupLocation"]["type"].IsBsonNull ? "null" : bsonDocument["pickupLocation"]["type"].AsString,
                    Name = bsonDocument["pickupLocation"]["name"].IsBsonNull ? "null" : bsonDocument["pickupLocation"]["name"].AsString,
                    PlaceId = bsonDocument["pickupLocation"]["placeId"].IsBsonNull ? "null" : bsonDocument["pickupLocation"]["placeId"].AsString,
                };
            }
            else
            {
                Assert.Fail("No pickup location data found in MongoDB.");
            }
        }

        [When(@"I read Delivery Location data from MongoDB")]
        public void WhenIUseReferenceIdToFetchDeliveryLocationDataFromMongoDB()
        {
            string collectionName = _configurationHelper.GetMongoDBCollectionName();
            var bsonDocument = _mongoDBUtility.FetchDeliveryLocation(_database, _xmlDeliveryLocationData.ReferenceId, collectionName);

            if (bsonDocument != null)
            {
                _mongoDeliveryLocationData = new DeliveryLocationData
                {
                    Id = bsonDocument["deliveryLocation"]["_id"].IsBsonNull ? "null" : bsonDocument["deliveryLocation"]["_id"].AsString,
                    Name = bsonDocument["deliveryLocation"]["name"].IsBsonNull ? "null" : bsonDocument["deliveryLocation"]["name"].AsString,
                    PlaceId = bsonDocument["deliveryLocation"]["placeId"].IsBsonNull ? "null" : bsonDocument["deliveryLocation"]["placeId"].AsString,
                };
            }
            else
            {
                Assert.Fail("No delivery location data found in MongoDB.");
            }
        }

        [When(@"I read Delivery TimeSlot data from MongoDB")]
        public void WhenIReadDeliveryTimeSlotDataFromMongoDB()
        {
            string collectionName = _configurationHelper.GetMongoDBCollectionName();
            var bsonDocument = _mongoDBUtility.FetchDeliveryTimeSlot(_database, _xmlDeliveryTimeSlotData.ReferenceId, collectionName);
            if (bsonDocument != null && !bsonDocument["deliveryTimeSlot"].IsBsonNull)
            {
                _mongoDeliveryTimeSlotData = new DeliveryTimeSlotData
                {
                    TimeSlotId = bsonDocument["deliveryTimeSlot"]["timeSlotId"].IsBsonNull ? "null" : bsonDocument["deliveryTimeSlot"]["timeSlotId"].AsString,
                    EarliestDay = bsonDocument["deliveryTimeSlot"]["earliestDay"].IsBsonNull ? "null" : bsonDocument["deliveryTimeSlot"]["earliestDay"].AsInt32.ToString(),
                    LatestDay = bsonDocument["deliveryTimeSlot"]["latestDay"].IsBsonNull ? "null" : bsonDocument["deliveryTimeSlot"]["latestDay"].AsString,
                    EarliestTime = bsonDocument["deliveryTimeSlot"]["earliestTime"].IsBsonNull ? "null" : bsonDocument["deliveryTimeSlot"]["earliestTime"].AsString,
                    LatestTime = bsonDocument["deliveryTimeSlot"]["latestTime"].IsBsonNull ? "null" : bsonDocument["deliveryTimeSlot"]["latestTime"].AsString,

                };
            }
            else
            {
                _mongoDeliveryTimeSlotData = new DeliveryTimeSlotData
                {
                    TimeSlotId = "null",
                    EarliestDay = "null",
                    LatestDay = "null",
                    EarliestTime = "null",
                    LatestTime = "null"
                };
            }
        }

        [When(@"I read Pickup TimeSlot data from MongoDB")]
        public void WhenIReadPickupTimeSlotDataFromMongoDB()
        {
            string collectionName = _configurationHelper.GetMongoDBCollectionName();
            var bsonDocument = _mongoDBUtility.FetchPickupTimeSlot(_database, _xmlDeliveryTimeSlotData.ReferenceId, collectionName);
            if (bsonDocument != null && !bsonDocument["pickupTimeSlot"].IsBsonNull)
            {
                _mongoPickupTimeSlotData = new PickupTimeSlotData
                {
                    TimeSlotId = bsonDocument["pickupTimeSlot"]["timeSlotId"].IsBsonNull ? "null" : bsonDocument["pickupTimeSlot"]["timeSlotId"].AsString,
                    EarliestDay = bsonDocument["pickupTimeSlot"]["earliestDay"].IsBsonNull ? "null" : bsonDocument["pickupTimeSlot"]["earliestDay"].AsInt32.ToString(),
                    LatestDay = bsonDocument["pickupTimeSlot"]["latestDay"].IsBsonNull ? "null" : bsonDocument["pickupTimeSlot"]["latestDay"].AsString,
                    EarliestTime = bsonDocument["pickupTimeSlot"]["earliestTime"].IsBsonNull ? "null" : bsonDocument["pickupTimeSlot"]["earliestTime"].AsString,
                    LatestTime = bsonDocument["pickupTimeSlot"]["latestTime"].IsBsonNull ? "null" : bsonDocument["pickupTimeSlot"]["latestTime"].AsString,
                };
            }
            else
            {
                _mongoPickupTimeSlotData = new PickupTimeSlotData
                {
                    TimeSlotId = "null",
                    EarliestDay = "null",
                    LatestDay = "null",
                    EarliestTime = "null",
                    LatestTime = "null"
                };
            }
        }

        [When(@"I read Pickup Location data from the XML file")]
        public void WhenIReadPickUpLocationDataFromTheXMLFile()
        {
            _xmlPickupLocationData = _xmlDataExtractor.ExtractPickupLocation(fileName);
            if (_xmlPickupLocationData == null)
            {
                Assert.Fail("Failed to extract pick up location data from the XML.");
            }
        }
        [When(@"I read the Delivery Location data from the XML file")]
        public void WhenIReadTheDeliveryLocationDataFromTheXMLFile()
        {
            _xmlDeliveryLocationData = _xmlDataExtractor.ExtractDeliveryLocation(fileName);
            if (_xmlDeliveryLocationData == null)
            {
                Assert.Fail("Failed to extract delivery location data from the XML.");
            }
        }

        [When(@"I read the Delivery TimeSlot data from the XML file")]
        public void WhenIReadTheDeliveryTimeSlotDataFromTheXMLFile()
        {
            _xmlDeliveryTimeSlotData = _xmlDataExtractor.ExtractDeliveryTimeSlot(fileName);
            if (_xmlDeliveryTimeSlotData == null)
            {
                Assert.Fail("Failed to extract deliveryTimeSlot data from the XML.");
            }
        }

        [When(@"I read the Pickup TimeSlot data from the XML file")]
        public void WhenIReadThePickupTimeSlotDataFromTheXMLFile()
        {
            _xmlPickupTimeSlotData = _xmlDataExtractor.ExtractPickupTimeSlot(fileName);
            if (_xmlPickupTimeSlotData == null)
            {
                Assert.Fail("Failed to extract  Pickup TimeSlot data from the XML.");
            }
        }

        [Then(@"I generate a report comparing XML data with MongoDB data")]
        public void ThenIGenerateAReportComparingXMLDataWithMongoDBData()
        {
            if (_xmlPickupLocationData == null || _mongoPickupLocationData == null || _xmlDeliveryLocationData == null || _mongoDeliveryLocationData == null || _xmlDeliveryTimeSlotData == null || _mongoDeliveryTimeSlotData == null)
            {
                Assert.Fail("One of the data sets is null. Cannot generate report.");
            }

            List<ReportRow> reportData = new List<ReportRow>
    {
        new ReportRow
        {
            Loc = _xmlPickupLocationData.Loc,
            FieldName = "_id",
            XmlValue = _xmlPickupLocationData.Id,
            MongoDbValue = _mongoPickupLocationData.Id,
            Result = _xmlPickupLocationData.Id == _mongoPickupLocationData.Id ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlPickupLocationData.Loc,
            FieldName = "type",
            XmlValue = _xmlPickupLocationData.Type,
            MongoDbValue = _mongoPickupLocationData.Type,
            Result = _xmlPickupLocationData.Type == _mongoPickupLocationData.Type ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlPickupLocationData.Loc,
            FieldName = "name",
            XmlValue = _xmlPickupLocationData.Name,
            MongoDbValue = _mongoPickupLocationData.Name,
            Result = _xmlPickupLocationData.Name == _mongoPickupLocationData.Name ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlPickupLocationData.Loc,
            FieldName = "placeId",
            XmlValue = _xmlPickupLocationData.PlaceId,
            MongoDbValue = _mongoPickupLocationData.PlaceId,
            Result = _xmlPickupLocationData.PlaceId == _mongoPickupLocationData.PlaceId ? "Pass" : "Fail"
        }
    };

            reportData.AddRange(new List<ReportRow>

    {
        new ReportRow
        {
            Loc = _xmlDeliveryLocationData.Loc,
            FieldName = "_id",
            XmlValue = _xmlDeliveryLocationData.Id,
            MongoDbValue = _mongoDeliveryLocationData.Id,
            Result = _xmlDeliveryLocationData.Id == _mongoDeliveryLocationData.Id ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlDeliveryLocationData.Loc,
            FieldName = "name",
            XmlValue = _xmlDeliveryLocationData.Name,
            MongoDbValue = _mongoDeliveryLocationData.Name,
            Result = _xmlDeliveryLocationData.Name == _mongoDeliveryLocationData.Name ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlDeliveryLocationData.Loc,
            FieldName = "placeId",
            XmlValue = _xmlDeliveryLocationData.PlaceId,
            MongoDbValue = _mongoDeliveryLocationData.PlaceId,
            Result = _xmlDeliveryLocationData.PlaceId == _mongoDeliveryLocationData.PlaceId ? "Pass" : "Fail"
        }
    });
          
            reportData.AddRange(new List<ReportRow>
    {
        new ReportRow
        {
            Loc = _xmlDeliveryTimeSlotData.Loc,
            FieldName = "timeSlotId",
            XmlValue = _xmlDeliveryTimeSlotData.TimeSlotId,
            MongoDbValue = _mongoDeliveryTimeSlotData.TimeSlotId,
            Result = _xmlDeliveryTimeSlotData.TimeSlotId == _mongoDeliveryTimeSlotData.TimeSlotId ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlDeliveryTimeSlotData.Loc,
            FieldName = "earliestDay",
            XmlValue = _xmlDeliveryTimeSlotData.EarliestDay,
            MongoDbValue = _mongoDeliveryTimeSlotData.EarliestDay,
            Result = _xmlDeliveryTimeSlotData.EarliestDay == _mongoDeliveryTimeSlotData.EarliestDay ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlDeliveryTimeSlotData.Loc,
            FieldName = "latestDay",
            XmlValue = _xmlDeliveryTimeSlotData.LatestDay,
            MongoDbValue = _mongoDeliveryTimeSlotData.LatestDay,
            Result = _xmlDeliveryTimeSlotData.LatestDay == _mongoDeliveryTimeSlotData.LatestDay ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlDeliveryTimeSlotData.Loc,
            FieldName = "earliestTime",
            XmlValue = _xmlDeliveryTimeSlotData.EarliestTime,
            MongoDbValue = _mongoDeliveryTimeSlotData.EarliestTime,
            Result = _xmlDeliveryTimeSlotData.EarliestTime == TrimSeconds(_mongoDeliveryTimeSlotData.EarliestTime) ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlDeliveryTimeSlotData.Loc,
            FieldName = "latestTime",
            XmlValue = _xmlDeliveryTimeSlotData.LatestTime,
            MongoDbValue = _mongoDeliveryTimeSlotData.LatestTime,
            Result = _xmlDeliveryTimeSlotData.LatestTime == TrimSeconds(_mongoDeliveryTimeSlotData.LatestTime) ? "Pass" : "Fail"
        }
    });
           
            reportData.AddRange(new List<ReportRow>
    {
        new ReportRow
        {
            Loc = _xmlPickupTimeSlotData.Loc,
            FieldName = "timeSlotId",
            XmlValue = _xmlPickupTimeSlotData.TimeSlotId,
            MongoDbValue = _mongoPickupTimeSlotData.TimeSlotId,
            Result = _xmlPickupTimeSlotData.TimeSlotId == _mongoPickupTimeSlotData.TimeSlotId ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlPickupTimeSlotData.Loc,
            FieldName = "earliestDay",
            XmlValue = _xmlPickupTimeSlotData.EarliestDay,
            MongoDbValue = _mongoPickupTimeSlotData.EarliestDay,
            Result = _xmlPickupTimeSlotData.EarliestDay == _mongoPickupTimeSlotData.EarliestDay ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlPickupTimeSlotData.Loc,
            FieldName = "latestDay",
            XmlValue = _xmlPickupTimeSlotData.LatestDay,
            MongoDbValue = _mongoPickupTimeSlotData.LatestDay,
            Result = _xmlPickupTimeSlotData.LatestDay == _mongoPickupTimeSlotData.LatestDay ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlPickupTimeSlotData.Loc,
            FieldName = "earliestTime",
            XmlValue = _xmlPickupTimeSlotData.EarliestTime,
            MongoDbValue = _mongoPickupTimeSlotData.EarliestTime,
            Result = _xmlPickupTimeSlotData.EarliestTime == TrimSeconds(_mongoPickupTimeSlotData.EarliestTime) ? "Pass" : "Fail"
        },
        new ReportRow
        {
            Loc = _xmlPickupTimeSlotData.Loc,
            FieldName = "latestTime",
            XmlValue = _xmlPickupTimeSlotData.LatestTime,
            MongoDbValue = _mongoPickupTimeSlotData.LatestTime,
            Result = _xmlPickupTimeSlotData.LatestTime == TrimSeconds(_mongoPickupTimeSlotData.LatestTime) ? "Pass" : "Fail"
        }
    });

            string referenceId = _xmlPickupLocationData.ReferenceId.Replace("/", "_").Replace(" ", "_").Replace(":", "_");
            string reportFilePath = Path.Combine(ITPConstant.ExcelOutputs, $"{referenceId}_{_xmlPickupLocationData.OrderType}.xlsx");
            _excelUtility.GenerateExcelReport(reportData, reportFilePath, _xmlPickupLocationData.OrderType);
        }
        private string TrimSeconds(string time)
        {
            if (time != null && time.Length == 8 && time.Contains(":"))
            {
                return time.Substring(0, 5);
            }
            return time;
        }

    }
}