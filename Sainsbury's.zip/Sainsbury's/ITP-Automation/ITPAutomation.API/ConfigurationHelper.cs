﻿using Microsoft.Extensions.Configuration;
using System.IO;

namespace ITPAutomation.API
{
    public class ConfigurationHelper
    {
        private IConfigurationRoot _configuration;

        public ConfigurationHelper()
        {
#if DEBUG
            _configuration = new ConfigurationBuilder()
                 .AddJsonFile($"appsettings.dev.json", optional: false, reloadOnChange: true)
                .AddUserSecrets(typeof(hooks).Assembly)
                .AddEnvironmentVariables()
                .Build();
#else
            _configuration = new ConfigurationBuilder()
                 .AddJsonFile($"appsettings.json", optional: false, reloadOnChange: true)
                .AddUserSecrets(typeof(hooks).Assembly)
                .AddEnvironmentVariables()
                .Build();
#endif

        }

        public string GetMongoDBConnectionString()
        {
            return _configuration.GetValue<string>("MongoConnectionString");
        }

        public string GetMongoDBDatabaseName()
        {
            return _configuration.GetValue<string>("MongoDBdatabaseName");
        }

        public string GetMongoDBCollectionName()
        {
            return _configuration.GetValue<string>("MongoDBCollectionName");
        }
    }
}
