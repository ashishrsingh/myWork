﻿using ITPAutomation.Infrastucture;
using OfficeOpenXml;
using System.Collections.Generic;
using System.IO;

namespace ITPAutomation.API
{
    public class ExcelUtility
    {
        public void GenerateExcelReport(List<ReportRow> reportData, string filePath, string orderType)
        {
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add("Comparison Report");
                worksheet.Cells[1, 1].Value = "OrderType";
                worksheet.Cells[1, 2].Value = "Loc";
                worksheet.Cells[1, 3].Value = "Field Name";
                worksheet.Cells[1, 4].Value = "XML Data";
                worksheet.Cells[1, 5].Value = "MongoDB Data";
                worksheet.Cells[1, 6].Value = "Result";

                int startRow = 2;
                foreach (var reportRow in reportData)
                {
                    worksheet.Cells[startRow, 1].Value = orderType;
                    worksheet.Cells[startRow, 2].Value = reportRow.Loc;
                    worksheet.Cells[startRow, 3].Value = reportRow.FieldName;
                    worksheet.Cells[startRow, 4].Value = reportRow.XmlValue;
                    worksheet.Cells[startRow, 5].Value = reportRow.MongoDbValue;
                    worksheet.Cells[startRow, 6].Value = reportRow.Result;
                    startRow++;
                }

                FileInfo file = new FileInfo(filePath);
                package.SaveAs(file);
            }
        }
    }
    public class ReportRow
    {
        public string Loc { get; set; }
        public string FieldName { get; set; }
        public string XmlValue { get; set; }
        public string MongoDbValue { get; set; }
        public string Result { get; set; }
    }
}