﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace ITPAutomation.Infrastucture
{
    public class ITPConstant
    {
        public static double passedCount = 0;
        public static double failedCount = 0;
        public static double totalCount = 0;
        public static string BasePath = GetTestFilePath("Testdoc", "");
        public static string appsettingBasePath = GetTestFilePath("", "");
        public static string blobStoragePlanITPath = "";
        public const string planITcontainerName = "planit";
        public static readonly string PlanITXMLSamples = Path.Combine(BasePath, @"PlanITXMLSamples/");
        public static readonly string ExcelOutputs = Path.Combine(BasePath, @"ExcelOutputs/");
        //MongoDBRunHistory
        public const string MongoDBRunHistoryCollectionName = "PlanITRunOfDay";
        public const string Plex_MongoDBRunHistoryCollectionName = "PlexRunHistory";
        public static readonly string XMLFilePath = Path.Combine(BasePath, @"PlanITXMLSamples/Valid/");

        public static string GetTestFilePath(string folderName, string fileName)
        {
            try
            {
                string startupPath = AppDomain.CurrentDomain.BaseDirectory;
                var pathItems = startupPath.Split(Path.DirectorySeparatorChar);
                var pos = pathItems.Reverse().ToList().FindIndex(x => string.Equals("bin", x));
                string projectPath = String.Join(Path.DirectorySeparatorChar.ToString(), pathItems.Take(pathItems.Length - pos - 1));
                string filepath = Path.Combine(projectPath, folderName, fileName);
                return filepath;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception occured in getting file path -" + ex.Message);
                throw;
            }
        }
    }
}
