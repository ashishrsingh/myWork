﻿
using System;
using System.Collections.Generic;
using System.Text;

namespace ITPAutomation.Infrastucture.Models
{
    public class AppSettings
    {
        public int MaxRetryAttempts { get; set; }
        public int SequenceResetHours { get; set; }
        public string OutputContainer { get; set; }
        public string SharePointSiteUrl { get; set; }
        public string SharePointUsername { get; set; }
        public string SharePointStaticPwd { get; set; }
        public string SharePointTokenEndpoint { get; set; }
        public string SharePointClientId { get; set; }
        public string SharePointEnvFolder { get; set; }
        public string SharePointLibrary { get; set; }
    }
}
