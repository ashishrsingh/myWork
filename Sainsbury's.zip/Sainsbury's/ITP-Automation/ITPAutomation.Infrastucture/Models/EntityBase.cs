﻿using MongoDB.Bson;
 

namespace ITPAutomation.Infrastucture.Models
{
    public abstract class EntityBase
    {

        public ObjectId Id { get; set; }
    }
}
