﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Text.Json;
//using System.Threading.Tasks;

//namespace ITPAutomation.Helpers
//{
//    public static class JsonHelper
//    {
//        public static string JsonPrettify(this string json)
//        {
//            using var jesonDoc = JsonDocument.Parse(json);
//            return JsonSerializer.Serialize(jesonDoc, new JsonSerializerOptions { WriteIndented = true });
//        }
//    }
//}
