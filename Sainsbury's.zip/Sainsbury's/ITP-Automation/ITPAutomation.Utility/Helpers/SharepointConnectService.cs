﻿//using Microsoft.Extensions.Logging;
//using Microsoft.Extensions.Options;
//using Microsoft.SharePoint.Client;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Security;
//using System.Text;
//using System.Threading.Tasks;

//namespace DEMO
//{
//    public class SharepointConnectService : ISharepointConnectService
//    {


//        private readonly AppSettings _appSettings;
//        private int maxRetry = 0;
//        public SharepointConnectService(IOptions<AppSettings> appSettings)
//        {

//            _appSettings = appSettings.Value;
//        }
//        public dynamic spconnect()
//        {
//            var reTry = 0;
//            while (true)
//            {
//                reTry++;
//                try
//                {
//                    Uri site = new Uri(_appSettings.SharePointSiteUrl);
//                    SecureString sec_pass = new SecureString();
//                    Array.ForEach(_appSettings.SharePointStaticPwd.ToArray(), sec_pass.AppendChar);
//                    sec_pass.MakeReadOnly();
//                    using (var authenticationManager = new AuthenticationManager())
//                    using (var context = authenticationManager.GetContext(site, _appSettings.SharePointUsername, sec_pass, _appSettings.SharePointClientId, _appSettings.SharePointTokenEndpoint))
//                    {
//                        context.Load(context.Web, p => p.Title);
//                        context.ExecuteQueryAsync();
//                        return context;
//                    }
//                }
//                catch (Exception ex)
//                {
//                    if (reTry == _appSettings.MaxRetryAttempts)
//                    {
//                        var errorMessage = $"Error ocuured in {nameof(spconnect)} while connecting to SharePoint file:  RetryCount: {reTry}";

//                        throw new Exception(errorMessage, ex);
//                    }

//                }
//            }
//        }

//    }
//}
